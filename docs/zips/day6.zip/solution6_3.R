# ------------------------------------------------------------
# Applied Statistics / Statistical methods in the Biosciences
# Solution to exercise 6.3
# Bo Markussen
# December 22, 2018
# ------------------------------------------------------------

# Read data
apple         <- read.delim("apples.txt")
apple$block   <- factor(apple$block)
summary(apple)

# Make and validate ANCOVA model including effect of block
m1 <- lm(y~block+cover*x,data=apple)
plot(m1)

# Some residuals are too large. So let's look for a Box-Cox transformation
library(MASS)
boxcox(m1)

# The logarithm look's promising. We also transform x to improve interpretation
m2 <- lm(log(y)~block+cover*log(x),data=apple)
plot(m2)

# This is better. We proceed to model reduction
drop1(m2,test="F")
m3 <- lm(log(y)~block+cover+log(x),data=apple)
drop1(m3,test="F")

# Estimates and post hoc comparisons of cover types
# Remember to back transform contrasts between covers to get relative comparisons on the weight scale (ie. in pounds)
library(emmeans)
cbind(estimate=coef(m3),confint(m3))
confint(emmeans(m3,~cover))

# and the associated Tukey grouping
CLD(emmeans(m3,~cover),Letters=letters)

# Only cover E and F are significantly different.
# So let's make a confidence interval for the ratio between these two covers
confint(pairs(emmeans(m3,~cover),type="response"))

# ----------------

# If the previous harvest isn't available, then we can not find significant differences anymore.
# Thus, using the previous harvest as a covariate makes the analysis more powerful!

drop1(lm(log(y)~block+cover,data=apple),test="F")
