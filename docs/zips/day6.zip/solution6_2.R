# ------------------------------------------------------------
# Applied Statistics / Statistical methods in the Biosciences
# Solution to exercise 6.2
# Bo Markussen
# December 22, 2018
# ------------------------------------------------------------

# Read data
rabbit          <- read.delim("rabbit.txt")
rabbit$day      <- factor(rabbit$day)
rabbit$rabbit   <- factor(rabbit$rabbit)
summary(rabbit)

# Make and validate the initial model: Ok
m1 <- lm(glucose~day+rabbit+dose,data=rabbit)
plot(m1)
shapiro.test(residuals(m1))

# Normality is borderline, so we try Box-Cox transformation
library(MASS)
boxcox(m1,lambda=seq(0,4,0.1))
m2 <- lm(glucose^3.5~day+rabbit+dose,data=rabbit)
plot(m2)
shapiro.test(residuals(m2))

# Box-Cox transformation does not improve normality. So we might as well use the non-transformed data

# Is there an effect? 
# Yes, p(dose)=0.03846
drop1(m1,test="F")

# Where is the effect?
# Not surprisingly it is dose A and C that are significantly different (adjusted p=0.0352).
# And the intermediate dose B is neither significantly different from A nor C.
library(emmeans)
CLD(emmeans(m1,~dose),Letters=letters,details=TRUE)
