# -------------------------------------------------------------
# Applied Statistics / Statistical methods in the Biosciences
# Design of experiments: Half fraction factorial design
# Bo Markussen
# December 15, 2016
# -------------------------------------------------------------

# load library
library(AlgDesign)

# Make full factorial design for 5 factors on 2 levels each
full.factorial <- gen.factorial(levels=2,nVars=5,varNames=c("FeedRate","Catalyst","AgitRate","Temp","Conc"))
full.factorial

# Make a design with 16 units 
# for main effects and 2-way interactions between 5 factors on 2 levels
optFederov(~(FeedRate+Catalyst+AgitRate+Temp+Conc)^2,data=full.factorial,nTrials=16)$design

# An error message is given if you try to make a design with too few experimental units
optFederov(~(FeedRate+Catalyst+AgitRate+Temp+Conc)^2,data=full.factorial,nTrials=15)$design
