# ------------------------------------------------------------
# Applied Statistics / Statistical methods in the Biosciences
# Solution to exercise 6.4
# Bo Markussen
# December 22, 2017
# ------------------------------------------------------------

# load library
library(AlgDesign)

# Make full factorial design for 3 factors on 3 levels each
full.factorial <- gen.factorial(levels=3,nVars=3,varNames=c("Rabbit","Day","Dose"))
full.factorial

# Recode the levels
full.factorial <- with(full.factorial,data.frame(
  Rabbit=factor(c("Rabbit 1","Rabbit 2","Rabbit 3")[2+Rabbit]),
  Day=factor(c("Day 1","Day 2","Day 3")[2+Day]),
  Dose=factor(c("Dose A","Dose B","Dose C")[2+Dose])))
full.factorial  

# Make a design with 9 units for main effects of 3 factors on 3 levels
latin.square <- optFederov(~Rabbit+Day+Dose,full.factorial,nTrials=9)$design
latin.square

# Check whether we have a latin square:
# This is the case if there is only one observations for each 
# combination of Dose, Rabbit and Day
xtabs(~.,latin.square) 
