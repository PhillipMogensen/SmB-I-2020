# -------------------------------------------------------------
# Applied Statistics / Statistical methods in the Biosciences
# Solution to Exercise 6.1: Instrumental variable
# Bo Markussen
# December 22, 2017
# -------------------------------------------------------------

# Simulate the dataset
N <- 100
C <- rnorm(N)
Z <- rnorm(N)
X <- 0.5*Z+0.5*C+rnorm(N)
Y <- 2*X+C+rnorm(N)

# Simple linear regression
# We see the spurious effect of the unobserved confounder
summary(lm(Y~X))

# Two step procedure
hatX <- predict(lm(X~Z))
summary(lm(Y~hatX))

# If we rerun the entire code several times, then it is apparent
# that the estimate is very variable.

# However, if we rerun the entire code with 'N <- 10000' in the first
# line, then we see that the two step procedure indeed works. But 
# that it needs many observations.

# If the confounder is available, then we simple can correct for
# the confounding
summary(lm(Y~C+X))
