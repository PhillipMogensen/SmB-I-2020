# ------------------------------------------------------------
# Applied Statistics / Statistical methods in the Biosciences
# Solution to Exercise 6.5
# Bo Markussen
# December 22, 2017
# ------------------------------------------------------------

# Load libraries
library(manipulate)

# Read data from txt-file
barley <- read.delim("barley.txt")
summary(barley)

# Make interactive plot
manipulate(
{
  plot(log(yield)~seeds,data=barley)
  x <- 0:80
  y <- a-b*exp(-c*x)
  lines(x,y)
}, 
a=slider(2,8,initial=5,step=0.1),
b=slider(0,4,initial=2,step=0.1),
c=slider(0,0.1,initial=0.045,step=0.005))

# Make non-linear regresion
m1 <- nls(log(yield)~a-b*exp(-c*seeds),start=list(a=4.8,b=2.6,c=0.06),data=barley)

# Parameter estimates
cbind(estimate=coef(m1),confint(m1))

# Neither of the confidence intervals are close to contain zero, so we have any reason to
# do hypothesis tests.

# Can the conclusions be trusted? Yes, the model validation plots look fine!
qqnorm(residuals(m1))
abline(mean(residuals(m1)),sd(residuals(m1)))

plot(predict(m1),residuals(m1),main="Residual by Predicted plot: Barley")
abline(0,0,lty=2)

# Reparameterization of the same model using the self-starting function SSasymp().
# Note that an initial guesses is not needed anymore. 
# Note also that SSasymp() models the same non-linear function as above, but
# using a different parameterization.
m2 <- nls(log(yield)~SSasymp(seeds,a,a.minus.b,log.c),data=barley)
cbind(estimate=coef(m2),confint(m2))
