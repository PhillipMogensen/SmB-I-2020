# --------------------------------------------------------
# Applied Statistics / Statistical methods for the Biosciences
# Random effects
# Hypothetical data example: 1-way ANOVA
# Bo Markussen
# December 10, 2020
# --------------------------------------------------------

# Package to make design diagram
library(LabApplStat)

# Data
rep1 <- data.frame(y=c(13.8,14.2,11.2,11.4,13.9,
                       13.1,12.3,11.0,14.0,10.7),
                   treat=factor(rep(1:2,each=5)),
                   animal=factor(1:10))
rep2 <- data.frame(y=c(13.7,14.3,11.1,11.3,14.1,
                       13.2,12.1,11.0,14.1,10.7),
                   treat=factor(rep(1:2,each=5)),
                   animal=factor(1:10))

# ANOVA table with only one observation for each animal
anova(lm(y~treat,data=rep1))
plot(DD(y~treat,data=rep1),"MSS")
#ggsave("../slides/figur/hypothetical1.pdf",width=3,height=1.5)

# Wrong analysis with two observations for each animal
anova(lm(y~treat+animal,data=rbind(rep1,rep2)))
plot(DD(y~treat+animal,data=rbind(rep1,rep2)),"MSS")
#ggsave("../slides/figur/hypothetical2.pdf",width=4,height=1.5)

# Design diagram for random effect model
plot(DD(y~treat,random=~animal,data=rbind(rep1,rep2)),"MSS")
#ggsave("../slides/figur/hypothetical3.pdf",width=4,height=1.5)
