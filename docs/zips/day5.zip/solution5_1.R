# --------------------------------------------------------------
# Applied Statistics / Statistical methods for the Biosciences
# Solution to Exercise 5.1
# Bo Markussen
# December 11, 2020
# --------------------------------------------------------------

# Load libraries
library(lme4)
library(LabApplStat)

# Read dataset: Recode the explanatory variables as factors
hypertension <- read.delim("hypertension.txt")
hypertension$patient <- factor(hypertension$patient)
hypertension$period  <- factor(hypertension$period)
str(hypertension)
summary(hypertension)

# Question 1: ----
# Fixed effects: drug, period, order, baseline
# Random effects: patient
# Response: change
# Not-used: end

# Question 2: Design diagram ----

# The following design diagram shows that the interaction period:drug has zero 
# degrees of freedom when order is included. Hence it doesn't make a difference to
# include the interaction. So we might as well not include the interaction.
plot(DD(change~order+period*drug,random=~patient,data=hypertension),"MSS")

# But why do "order" and "period:drug" describe the same thing?
# The interpretation of "period:drug" as a modification of "drug"
# says that difference between drug E and drug N, i.e. E-N, may
# depend on the period. In period 1 we have the difference
#
# diff1 = mean(1,E) - mean(1,N)
# 
# and in period 2 we have difference
#
# diff2 = mean(2,E) - mean(2,N)
# 
# Thus, the interaction "period:drug" models the difference of 
# differences. That is,
#
# diff1 - diff2 = (mean(1,E)+mean(2,N)) - (mean(1,N)+mean(2,E))
#
# But this is exactly that same constrast that is modeled by "order".
#
# Or explained in words: The patients in the E/N group only
# experience the two drugs in a situation where you might have
# synergistic (or antagonistic) effect between period=1 and drug=E, 
# and between period=2 and drug=N. And the patients in the N/E group
# only experience the two drugs in a situation where you might have
# synergistic (or antagonistic) effect between period=1 and drug=N, 
# and between period=2 and drug=E. 


# Question 3: Data analysis ----

# We fit a LMM (linear mixed effects model) using baseline, but 
# not interaction period:drug
m1 <- lmer(change~baseline+order+period+drug+(1|patient),data=hypertension)

# Can the conclusions be trusted? I.e. model validation
plot(m1)
qqnorm(residuals(m1))
qqnorm(ranef(m1)$patient[,1])

# Conclusion: Model validity look's ok!

# Is there an effect?

# A likelihood ratio test shows a significant effect 
# of drug (p=0.04995)
drop1(m1,test="Chisq")

# What is the effect?

# We look at the em-means for change
emmeans(m1,~drug)
confint(pairs(emmeans(m1,~drug)))

# Conclusion: It looks as if drug E lowers the blood pressure,
# wheras drug N does not appear to have any effect.


# Question 4: Comparison with T-test from Exercise 1.5 ----

# In the analysis done in question 3 we were able to establish
# a significant (p=0.04995) difference between drug E and N. Whereas
# the T-test done in Exercise 1.5 wasn't able to establish a
# significant difference (p=0.0932). In this way the ANCOVA analysis
# is more powerful. The reason for this is, that model m1 also controls 
# for the baseline as well as the period. 

# However, if we would have done model selection before the
# hypothesis tests then we get the following result

drop1(m1,test="Chisq")
drop1(m2 <- update(m1,.~.-order),test="Chisq")
drop1(m3 <- update(m2,.~.-period),test="Chisq")

# Thus, model selection will remove both order and period (eg. looking
# at the AIC value). Then we get model m3, where the effect of drug is 
# non-significant (p=0.08502). This p-value is comparable to what we 
# found using T-tests (which gave p=0.0932).

# Thus, the conclusion depend on whether we do model selection or not!
# So it is very delicate.


# Question 5: Communication ----

# The ANCOVA model m1 proposed in the solution to question 3 is
# somewhat complicated. However, it is only one model that needs to
# be described and understood. 
# 
# On the other hand the 4 T-tests done in Exercise 1.5 are more
# simple by them selves. But is all details are to be given, then
# it requires a lot of explanation.
#
# So personally I prefer the ANCOVA model. Here all effects can
# be explained and understood together in a single model.
