# --------------------------------------------------------------
# Applied Statistics / Statistical methods for the Biosciences
# Repeated measurements: Growth of Baobab trees
# Bo Markussen
# December 13, 2019
# -----------------------------------------------

# Load libraries ----
library(readxl)
library(nlme)
library(MASS)
library(emmeans)
library(tidyverse)

# Read Excel sheet ----
baobab <- read_excel("baobab_growth.xls")
baobab$Plant <- factor(baobab$Plant)
baobab$Block <- factor(baobab$Block)
baobab$Treatment <- factor(baobab$Treatment)
baobab

# We choose to exclude non-harvested trees
# In particular, the analysis is conditional on survival
# until harvest.
baobab <- subset(baobab,!is.na(HarvestDate))
baobab$Plant <- droplevels(baobab$Plant)
baobab

# Transform to long form ----
# Remarks: 
# 1) Here done using the pivot_longer() from the tidyverse.
#    Since we transform both the diameter (=Dia) and 
#    the height(=Hei) in one go the syntax is somewhat complicated.
# 2) In the first mutate() step we define plant age as months since
#    January, 2009. The as.numeric() is necessary to make the
#    conversion from characters to numbers.
# 3) In the rename() step we change variable names from Dia and Hei
#    to diameter and height, respectively.
baobab %>% 
  pivot_longer(cols=Dia0209:Hei0110,
               names_to = c(".value","month","year"),
               names_sep = c(3,5),
               values_drop_na = TRUE) %>%
  mutate(age=(as.numeric(month)-1)+12*(as.numeric(year)-09)) %>%
  mutate(Treatment=factor(Treatment)) %>%
  rename(diameter=Dia,height=Hei) %>%
  filter(diameter > 0) %>%
  filter(height > 0) ->
  long
View(long)  


# Find optimal Box-Cox transformation of the two responses ----

# Conclusion: use diameter^(2/3)
tmp <- MASS::boxcox(lm(diameter~Treatment*Block+Treatment*factor(age)*Provenance,data=long))
tmp$x[which.max(tmp$y)]

# Conclusion: use height^(1/2)
tmp <- MASS::boxcox(lm(height~Treatment*Block+Treatment*factor(age)*Provenance,data=long))
tmp$x[which.max(tmp$y)]


# Visualization of raw data ----

# Individual profiles 

ggplot(long) + geom_line(aes(x=age,y=diameter^(2/3),group=Plant)) + facet_grid(.~Country) +
  scale_x_continuous(breaks=seq(2,12,2))
#ggsave("../slides/figur/individual_diameter.pdf",width=4,height=3)

ggplot(long) + geom_line(aes(x=age,y=height^(1/2),group=Plant)) + facet_grid(.~Country) +
  scale_x_continuous(breaks=seq(2,12,2))
#ggsave("../slides/figur/individual_height.pdf",width=4,height=3)


# Average profiles

ggplot(long) + geom_smooth(aes(x=age,y=diameter^(2/3),group=Treatment,col=Treatment)) + 
  facet_grid(.~Country) +
  scale_x_continuous(breaks=seq(2,12,2))
#ggsave("../slides/figur/average_diameter.pdf",width=5,height=3)


# Fit three repeated measurements models ----

mRI    <- lme(diameter^(2/3)~Treatment*Block+Treatment*factor(age)*Provenance,random=~1|Plant,
              data=long,na.action=na.omit)
mExp   <- lme(diameter^(2/3)~Treatment*Block+Treatment*factor(age)*Provenance,random=~1|Plant,
              corr=corExp(form=~age|Plant,nugget=TRUE),data=long,na.action=na.omit)
mGauss <- lme(diameter^(2/3)~Treatment*Block+Treatment*factor(age)*Provenance,random=~1|Plant,
              corr=corGaus(form=~age|Plant,nugget=TRUE),data=long,na.action=na.omit)

# Selection and validation of initial model ----

# Extract AIC: The AIC suggests that Exponential decrease model should be used
anova(mRI,mExp,mGauss)

# Validation of Exponential decrease model ----
#pdf("Exp_variogram.pdf",width=6,height=6)
plot(Variogram(mExp),ylim=c(0,0.7),main="Exponential decrease model")
plot(mExp,main="Exponential decrease model")
qqnorm(resid(mExp),main="Exponential decrease model")
#dev.off()

# Validation of Diggle model
plot(Variogram(mGauss),ylim=c(0,1.1),main="Diggle model")
plot(mGauss,main="Diggle model")
qqnorm(resid(mGauss),main="Diggle model")


# Automatic model reduction using AIC ----

# Using stepAIC() from the MASS-package.
# Remember to refit the model using method="ML" first!

mExp.ML <- lme(diameter^(2/3)~Treatment*Block+Treatment*factor(age)*Provenance,random=~1|Plant,
               corr=corExp(form=~age|Plant,nugget=TRUE),data=long,na.action=na.omit,
               method="ML")
stepAIC(mExp.ML,direction="both",trace=6)

# Remark: The computations take time! So be patient!
# Remark: The trace=6 option allows you to see the function at work.
#         In particular, you can see that it is doing something :-).


# Refit selected model using REML ----
mExp.final <- lme(diameter^(2/3) ~ Treatment + Block + factor(age) + Provenance + 
                    Treatment:factor(age) + Treatment:Provenance + factor(age):Provenance,  
                  random=~1|Plant,corr=corExp(form=~age|Plant,nugget=TRUE),data=long,na.action=na.omit)

# Visualization of selected model ----
my.emm <- as.data.frame(emmeans(mExp.final,~factor(age)|Treatment:Provenance))

# we backtransform by hand
ggplot(my.emm) + 
  geom_line(aes(x=age,y=emmean^(3/2),group=Treatment,col=Treatment)) +
  geom_errorbar(aes(x=age,ymin=lower.CL^(3/2),ymax=upper.CL^(3/2),col=Treatment)) + 
  facet_wrap(.~Provenance,ncol=4) +
  scale_x_continuous(breaks=seq(2,12,2)) +
  ylab("Diameter")
#ggsave("../slides/figur/baobab_emm.pdf",width=14,height=8,unit="cm")
