# --------------------------------------------------------------
# Applied Statistics / Statistical methods for the Biosciences
# Solution to Exercise 5.3
# Bo Markussen
# December 13, 2019
# --------------------------------------------------------------

# Load libraries
library(lme4)
library(emmeans)

# Read dataset: Recode some of the variables as factors
diet <- read.delim("diet.txt")
diet$person <- factor(diet$person)
diet$diet   <- factor(diet$diet)
summary(diet)

# ---------------------------------------
# Make valid model
# ---------------------------------------

# Fit GLMM (generalized linear mixed effects model)
m1 <- glmer(cbind(loss,gain)~diet+(1|person),family=binomial,data=diet)

# Validate normality of random effects: The predicted random effects are ok normal.
qqnorm(ranef(m1)$person[,1])
shapiro.test(ranef(m1)$person[,1])

# The following hypothesis test shows strong evidence of overdispersion
m0 <- glm(cbind(loss,gain)~diet,family=binomial,data=diet)
anova(m1,m0)


# ---------------------------------------
# Is there an effect?
# ---------------------------------------

drop1(m1,test="Chisq")

# p(diet,df=1) = 0.204

# Conclusion: The effect of diet is non-significant!

# ---------------------------------------
# Compare with other approaches
# ---------------------------------------

# Generalized Estimation Equations (GEE): p(diet,df=1) = 0.2664
library(gee)
m2 <- gee(cbind(loss,gain)~diet,id=person,family=binomial,data=diet,corstr="independence")
summary(m2)
2*(1-pnorm(1.111220))

# Quasi binomial: p(diet,df=1) = 0.2878
m3 <- glm(cbind(loss,gain)~diet,family=quasibinomial,data=diet)
drop1(m3,test="Chisq")

# Conclusion: All 3 approaches agree on no effect of diet!

# --------------------
# Odds ratio
# --------------------

# Even though the effect of diet is non-significant we will estimate 
# the odds ratio for weight loss between the diet 1 and diet 2
confint(pairs(emmeans(m1,~diet,type="response")))

# Thus, the odds for weigh loss is estimated to be higher in diet 1,
# although the odds ratio is not significantly different from 1 as 
# seen above.
