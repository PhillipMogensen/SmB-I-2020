# -------------------------------------------------------------
# Applied Statistics / Statistical methods in the Biosciences
# Solution to Exercise 5.2
# Bo Markussen
# December 11, 2020
# -------------------------------------------------------------

# Load libraries
library(lme4)
library(MASS)
library(LabApplStat)

# Read dataset: Recode the explanatory variables as factors
milk <- read.delim("milk.txt")
milk$round <- factor(milk$round)
milk$week  <- factor(milk$week)
milk$water <- factor(milk$water)
milk$temp  <- factor(milk$temp)
str(milk)
summary(milk)

# Design diagram
plot(DD(maillard~week*water*temp,random=~round:water:temp+round,data=milk))

# ---------------------------------------
# Validate initial model
# ---------------------------------------

# Fit LMM (linear mixed effects model)
m0 <- lmer(maillard~week*water*temp+(1|round:water:temp)+(1|round),data=milk)

# Validate model: remember that we have two sets of random effects in our model
plot(m0)
qqnorm(residuals(m0))
qqnorm(ranef(m0)$'round:water:temp'[,1])
qqnorm(ranef(m0)$'round'[,1])

# Residul plots does not look too nice, so we would like to try a Box-Cox analysis.
# However, MASS::boxcox() does not work on lmer-models. So we do the Box-Cox analysis
# on the corresponding lm-model without the random effects
boxcox(lm(maillard~week*water*temp,data=milk),lambda = seq(-3,2,0.1))

# Box-Cox suggests that we analyze 1/(maillard^2). So let's do that.
# Remark: For this exercise it is also ok if you forget about this aspect :-)

# Fit LMM (linear mixed effects model) on transformed response
m1 <- lmer(1/maillard^2~week*water*temp+(1|round:water:temp)+(1|round),data=milk)

# Validate model: remember that we have two sets of random effects in our model
plot(m1)
qqnorm(residuals(m1))
qqnorm(ranef(m1)$'round:water:temp'[,1])
qqnorm(ranef(m1)$'round'[,1])

# Conclusion: Model validity didn't improve much. Both models, however, are sufficiently good
# to be used. We proceed with the model on the non-transformed data since this model is most
# easy to interpret.

# ---------------------------------------
# Is there an effect?
# ---------------------------------------

# Do model selection starting from m0, which has non-transformed response
drop1(m0,test="Chisq")
drop1(m2 <- update(m0,.~.-week:water:temp),test="Chisq")
drop1(m3 <- update(m2,.~.-week:water),test="Chisq")
drop1(m4 <- update(m3,.~.-water:temp),test="Chisq")
drop1(m5 <- update(m4,.~.-week:temp),test="Chisq")

# all 3 main effects are kept by AIC and also significant

# ---------------------------------------
# Where is the effect? : emmeans
# ---------------------------------------

# emmeans for maillard in the 3 different weeks
emmeans(m5,~week)
CLD(emmeans(m5,~week),Letters=letters)
pairs(emmeans(m5,~week))

plot(emmeans(m5,~week))

# Remark:
# Although the confidence intervals for the em-means for 'week' overlap to large extent,
# the pairwise comparisons are highly significant. This behavior is often seen. The
# reason is, that the confidence intervals for the em-means themselves also includes 
# the uncertainty on the estimation of the remaining factors. These, however, disappear
# in the pairwise comparisons within 'week'.

# em-means for 'water' and 'temp' are done similarly.
