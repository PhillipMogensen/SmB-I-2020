# --------------------------------------------------------------
# Applied Statistics / Statistical methods for the Biosciences
# Day 5: Random effects
# Data example: Redness of pork chops
# Bo Markussen
# December 12, 2019
# --------------------------------------------------------

# Load libraries
library(LabApplStat)
library(lme4)
library(emmeans)
library(ggplot2)

# Read dataset: Recode some of the variables as factors
redness <- read.delim("redness.txt")
redness$pig <- factor(redness$pig)
redness$time <- factor(redness$time)
str(redness)

# ---------------------------------------
# Make valid model
# ---------------------------------------

# Fit random effects model
m0 <- lmer(redness~breed*storage*time+(1|pig),data=redness)

# Residual plot
plot(m0)

# Normal quantile plots
qqnorm(residuals(m0))
qqnorm(ranef(m0)$pig[,1])

# Conclusion: Validity doesn't look nice. Probably due to observation no. 44.
# Thus, we remove this outlier and revalidate the model

# Fit random effects model
m1 <- lmer(redness~breed*storage*time+(1|pig),data=redness[-44,])

# Model validation
plot(m1)
qqnorm(residuals(m1))
qqnorm(ranef(m1)$pig[,1])

# Conclusion: Model validity now look's fine

# Design Diagram
pdf("redness_MSS.pdf",width=8,height=8)
plot(DD(redness~breed*storage*time,random=~pig,data=redness[-44,]),"MSS")
dev.off()

# ---------------------------------------
# Is there an effect? : Model reduction
# ---------------------------------------

# Remark: drop1 refits using ML. This may be seen comparing AIC(m1) to drop1(m1)
AIC(m1)

# Test and reduce model
drop1(m1,test="Chisq")
drop1(m2 <- update(m1,.~.-breed:storage:time),test="Chisq")
drop1(m3 <- update(m2,.~.-breed:time),test="Chisq")
drop1(m4 <- update(m3,.~.-breed:storage),test="Chisq")

# p(breed)        = 0.0141, df=1
# p(storage:time) = 0.0001, df=2

# Remark: 
# 1) The usual step() function for doing automated model selection
# does not work for lmer-models. However, you may use the step() 
# function from the lmerTest-package. 
# 2) The default behavior for lmerTest::step() is that it also tries to 
# remove random effects. Usually I don't like this. So to keep all random effects
# set the option reduce.random=FALSE. 
# 3) Another thing is that lmerTest::step() use p-values instead of AIC to select
# models. For this I often select on a 10pct significance level.
# 4) Finally, a technicality: The lmerTest-package has it's own version
# of the lmer() function. And the model has to be fitted using this version
# in order for the associated step() function to work.
#
# Thus, the code would look like specified in the comment below

# library(lmerTest)
# m1 <- lmer(redness~breed*storage*time+(1|pig),data=redness[-44,])
# step(m1,reduce.random = FALSE,alpha.fixed = 0.1)


# ---------------------------------------
# Where is the effect? : emmeans
# ---------------------------------------

# breed
pairs(emmeans(m4,~breed),reverse=TRUE)
confint(pairs(emmeans(m4,~breed),reverse=TRUE))

# storage:time
CLD(emmeans(m4,~storage:time))

# visualization of effect of time within storage types
plot(emmeans(m4,~time|storage),int.adjust="tukey",horizontal=FALSE) +
  ylab("Redness of meat") +
  ggtitle("95pct simultaneous confidence intervals within storage")
#ggsave("emmeans.pdf",width=13,height=10,units="cm")


# ----------------------------------------
# Quantification of sources of variation
# ----------------------------------------

summary(m4)

cat("Total variance=",0.200+1.923,"\n")
cat("  percentage from variation between pigs=",round(100*0.200/(0.200+1.923)),"\n")
cat("  percentage from other sources=",round(100*1.923/(0.200+1.923)),"\n")
