# ------------------------------------------------------------
# Applied Statistics / Statistical methods in the Biosciences
# Solution to exercise 4.3
# Bo Markussen
# December 5, 2019
# ------------------------------------------------------------

# Read data
sphagnum        <- read.delim("sphagnum.txt")
sphagnum$lot    <- factor(sphagnum$lot)
sphagnum$trough <- factor(sphagnum$trough)
summary(sphagnum)

# Make and validate the additive model
m1 <- lm(volume~lot+trough,data=sphagnum)
plot(m1)

# We remove observation no. 46
m2 <- lm(volume~lot+trough,data=sphagnum[-46,])
plot(m2)

# load library
library(emmeans)

# make and plot em-means
emmeans(m2,~lot)
plot(emmeans(m2,~lot))

# Tukey grouping of em-means
# Note: the p-values are adjusted for multiple testing,
#       but the confidence intervals are not adjusted!
CLD(emmeans(m2,~lot))

# Remark: The author of the emmeans-package, Russell Lenth,
#   does not like the CLD, and intend to remove this
#   functionality from the package. I disagree on this.
#   Luckily, in the future you may use multcomp::cld() in
#   place of CLD().

# As an replacement for the CLD() functionality Russell
# proposes the following plot. Personally, I find this
# display to be too busy. But what do you think=
pwpp(emmeans(m2,~lot))

# An alternative to pwpp() is to find and plot
# simultaneous confidence intervals.
# Note, however, that replacing hypothesis tests by 
# looking for overlap between confidence intervals
# may be misleading.
confint(emmeans(m2,~lot),adjust="tukey")
plot(confint(emmeans(m2,~lot),adjust="tukey"))
