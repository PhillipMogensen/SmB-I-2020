# -------------------------------------------------------------
# Applied Statistics / Statistical methods in the Biosciences
# Solution to Exercise 4.2
# Bo Markussen
# December 11, 2017
# -------------------------------------------------------------

# Read data from txt-file
wr <- read.delim("WR2011.txt")
head(wr)
summary(wr)
str(wr)

# Make first plot
library(ggplot2)
ggplot(wr) + geom_point(aes(x=distance,y=time,col=sex))

# Make second plot
ggplot(wr) + geom_point(aes(x=distance,y=time,col=sex)) +
  scale_x_log10() + scale_y_log10()


# Make and validate ANCOVA model
m1 <- lm(log(time)~sex+log(distance)+sex:log(distance),data=wr)
par(mfrow=c(2,2)); plot(m1)

# Find position of 'bend' in residual plot
# Remark: After calling the identify() function below, the graphical
#         window becomes "alive". You can now mouse-click on points inside
#         inside the window. When you are done click the "Finish" button
#         in the upper-right of the graphical panel, and the selected 
#         points will be identified!
# Remark: In my try I selected point number 6 and 22, which correspond
#         to the 1500 meter run for men and women.
par(mfrow=c(1,1))
plot(predict(m1),residuals(m1),main="Residual plot")
identify(predict(m1),residuals(m1))
wr[c(6,22),]

# Make and validate extended ANCOVA model
m2 <- lm(log(time)~sex+log(distance)+sex:log(distance)+sex:log(bend),data=wr)
par(mfrow=c(2,2)); plot(m2)

# And without the shortest and the non-standard running distances
m3 <- lm(log(time)~sex+log(distance)+log(bend)+sex:log(distance)+sex:log(bend),
         data=wr[-c(1,11,12,14,15,17,27,28,30,31),])
par(mfrow=c(2,2)); plot(m3)

# Model reduction
step(m3)
m4 <- lm(log(time)~sex+log(distance)+log(bend),data=wr[-c(1,11,12,14,15,17,27,28,30,31),])
drop1(m4,test="F")

# Confidence intervals: In particular, women run 11.8pct slower than men.
cbind(estimate=coef(m4),confint(m4))
exp(cbind(women.vs.men=coef(m4),confint(m4))[2,])

# The last computation with the backtransformation can also be done via the emmeans-package.
library(emmeans)
pairs(emmeans(m4,~sex),type="response",reverse=TRUE)
