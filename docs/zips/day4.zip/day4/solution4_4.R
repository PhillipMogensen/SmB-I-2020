# -------------------------------------------------------------
# Applied Statistics / Statistical methods in the Biosciences
# Solution to Exercise 4.4
# Bo Markussen
# May 14, 2016
# -------------------------------------------------------------

# Read data from txt-file
phosphor <- read.delim("phosphor.txt")
summary(phosphor)

# Make multilinear regresion
m1 <- lm(available~inorganic+organic,data=phosphor)

# 4. Can the conclusions be trusted?
# The classical validation plots
par(mfrow=c(2,2)); plot(m1)

# Analysis without observation no. 17
m2 <- lm(available~inorganic+organic,data=phosphor[-17,])
plot(m2)

# We will also try a logaritmic transformation
m3 <- lm(log(available)~inorganic+organic,data=phosphor)

# 4. Can the conclusions be trusted?
# The classical validation plots
plot(m3)

# Model m3 is valid. So we will do the statistical analysis using this model.

# Is there an effect? Yes, of inorganic phosphor
# Remark: The update() function allows you to remove / add individual effects
#         without writing all the other effects. Thus, ".~.-organic" means "the
#         same model as before, just without the organic variable".
drop1(m3,test="F")
m4 <- update(m3,.~.-organic)
drop1(m4,test="F")

# What is the effect?
summary(m4)
cbind(estimate=coef(m4),confint(m4))
