# -------------------------------------------------------------
# Applied Statistics / Statistical methods in the Biosciences
# Day 4: Estimated marginal means in an ANCOVA
# Bo Markussen
# December 6, 2018
# -------------------------------------------------------------

# load libraries
library(emmeans)
library(LabApplStat)
library(tidyverse)

# Read data on strength of men and women
strength <- read.delim("strength.txt")
summary(strength)

# T-test
t.test(strength~sex,data=strength)

# Make and validate ANCOVA
m1 <- lm(strength~sex*lean.body.mass,data=strength)
par(mfrow=c(2,2)); plot(m1)

# Model reduction
drop1(m1,test="F")
m2 <- lm(strength~sex+lean.body.mass,data=strength)

# Design Diagram
plot(DD(~sex+lean.body.mass,data=strength)) + theme_void()
ggsave("../Slides/figur/strength_DD.pdf",height = 6, width = 10, units = "cm")

plot(DD(~sex*lean.body.mass,data=strength,center=FALSE)) + theme_void()
ggsave("../Slides/figur/strength_DD2.pdf",height = 6, width = 12, units = "cm")

# -------------------------------------------------------------------------
# Balanced LS-means (standard em-means, also used by the emmeans-package)
# -------------------------------------------------------------------------

emmeans(m2,~sex)

# And here is the contrast of the balanced em-means between men and women
pairs(emmeans(m2,~sex))

# -----------------------------------------------------------------------------------------
# Marginalized LS-means, where the means for the covariates are computed within the sexes
# -----------------------------------------------------------------------------------------

emmeans(m2,~sex,cov.reduce = lean.body.mass~sex)

# And here is the contrast of the marginalized ls-means between men and women
pairs(emmeans(m2,~sex,cov.reduce = lean.body.mass~sex))
