# -------------------------------------------------------------
# Applied Statistics / Statistical methods in the Biosciences
# Day 4: Height of sons and parents
# Bo Markussen
# December 12, 2020
# -------------------------------------------------------------

library(HistData)
library(tidyverse)

# Load data from HistData-package
# Only keep data from a randomly selected son

data("GaltonFamilies")
set.seed(03122020)
as_tibble(GaltonFamilies) %>% filter(gender=="male") %>% group_by(family) %>% slice_sample(n=1) -> height

# Make linear regresion
son.father <- lm(childHeight~father,data=height)

# 4. Can the conclusions be trusted?
# The classical validation plots
par(mfrow=c(2,2))
plot(son.father)

# If you are uncertain about whether the residual and qq-plots are sufficiently nice, 
# then you may try MESS::wallyplot()
library(MESS)
wallyplot(son.father,FUN=residualplot)
qqnorm.wally <- function(x, y, ...) { qqnorm(y, ...) ; abline(a=0, b=1) }
wallyplot(son.father,FUN=qqnorm.wally)

# An alternative is, of course, to use cumulative residuals
library(gof)
plot(cumres(son.father))

# 1. Is there an effect?
drop1(son.father,test="F")

# Somewhat anoying the drop1() does not give denominator degrees of freedom.
# If necessary these may be found as the Redisuals(Df) from the anova().
# However, be careful when using anova() when there are more than 1 explanatory variable.
# The anova() namely does sequential test starting from the model without explanatory variables.
anova(son.father)

# 3. What is the effect?
# May be done using coef() and confint(). Here, however, the function gmodels::ci() also is useful
library(gmodels)
ci(son.father)


# ---------------------------------------------
# Graphics to be used on the lecture slides
# ---------------------------------------------

# Model validation plots ----
pdf("../Slides/figur/galton_validation.pdf",width=6,height=5)
par(mfrow=c(2,2),mar=c(4.1,4.1,3.1,2.1))
plot(son.father)
dev.off()

# Observed and Model plot ----
# Plot shows both data points as wells as estimated regression line together
# with confidence and prediction intervals.
x <- seq(min(height$father),max(height$father),length.out = 100)
pred.height <- cbind(data.frame(father=x),
                     predict(son.father,interval="prediction",newdata=data.frame(father=x)))
ggplot(height,aes(x=father,y=childHeight)) +
  geom_smooth(method="lm") + 
  geom_point() +
  geom_line(aes(x=father,y=lwr),data=pred.height,col="red",lty=2) +
  geom_line(aes(x=father,y=upr),data=pred.height,col="red",lty=2) +
  coord_equal() +
  ggtitle("Height of sons and their fathers") +
  theme_light()
ggsave("../Slides/figur/galton_fit.pdf",width = 10, units = "cm")


# Actual by Predicted Plot
pdf("../Slides/figur/galton_AP.pdf",width=5,height=5.5)
plot(predict(son.father),height$childHeight,main="Actual by Predicted",xlim=c(60,80),ylim=c(60,80),
     xlab="Predicted from fathers height",ylab="Observed height of son")
x <- seq(60,80,0.1)
matlines(x,predict(son.father,interval="prediction",newdata=data.frame(father=x)),col=c(1,3,3),lty=c(1,3,3),lwd=2)
dev.off()

# Regression toward the mean
pdf("../Slides/figur/regression_toward_mean.pdf",width=5,height=5.5)
plot(childHeight~father,data=height,main="Height of sons and their fathers",xlim=c(60,80),ylim=c(60,80))
abline(son.father,lwd=2,col="blue")
x <- coef(lm(father~childHeight,data=height))
abline(-x[1]/x[2],1/x[2],lwd=2,col="red")
legend("topleft",c("response=son","response=father"),lwd=2,col=c("blue","red"))
dev.off()
