# -------------------------------------------------------------
# Applied Statistics / Statistical methods in the Biosciences
# Solution to Exercise 4.1: Multilinear regression
# Bo Markussen
# December 4, 2020
# -------------------------------------------------------------

# Read data from txt-file
wage <- read.delim("wage.txt")
str(wage)
summary(wage)

# linear models
summary(lm(wage~edu+exper+age,data=subset(wage,(sex==1)&(occup==5))))
summary(lm(wage~edu+exper,data=subset(wage,(sex==1)&(occup==5))))
with(subset(wage,(sex==1)&(occup==5)),cor.test(edu,exper))
summary(lm(age~edu+exper,data=wage))

# Spotting correlation between pairs of covariates is often
# done making pairwise scatterplot and correlations:
pairs(wage[(wage$sex==1)&(wage$occup==5),c("edu","exper","age")])
cor(wage[(wage$sex==1)&(wage$occup==5),c("edu","exper","age")])

# Remark: A fancy version of the pairwise scatter plots is available from the GGally-package
library(GGally)
ggpairs(wage[(wage$sex==1)&(wage$occup==5),c("edu","exper","age")])

# In the present dataset we easily see that exper and age are quite correlated. 
# However, multicollinarity between 3 or more covariates may not be identifiable
# from the pairwise plots. One method to catch that is to do a so-called 
# principal component analysis (PCA):
summary(prcomp(wage[(wage$sex==1)&(wage$occup==5),c("edu","exper","age")],scale=TRUE))

# From the 'Cumulative Proportion' we see that 2 principal components
# almost explain all the variation in the covariates. This implies
# that there is multicollinearity between the 3 covariates (since 2 < 3).
