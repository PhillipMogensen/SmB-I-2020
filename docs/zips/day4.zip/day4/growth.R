# --------------------------------------------------------------
# Applied Statistics / Statistical methods for the Biosciences
# Day 4: Growth of rats
# Bo Markussen
# December 5, 2019
# --------------------------------------------------------------

# Load libraries
library(LabApplStat)
library(emmeans)
library(tidyverse)

# Make data frame
rats <- data.frame(antibio=rep(c(0,40),each=6),
                   vitamin=rep(rep(c(0,5),each=3),times=2),
                   growth=c(1.30, 1.19, 1.08,1.26, 1.21, 1.19, 1.05, 1.00, 1.05, 1.52, 1.56, 1.55))
rats

# Remark: Above 'antibio' and 'vitamin' have been encoded as numerical variables.
#         This namely provides the better graphical layout for the interaction plots.

# Interaction plots
ggplot(rats,aes(x=antibio,y=growth,col=factor(vitamin))) + geom_smooth(method="lm") + geom_point() +
  ggtitle("Modification of antibio effect")

ggplot(rats,aes(x=vitamin,y=growth,col=factor(antibio))) + geom_smooth(method="lm") + geom_point() +
  ggtitle("Modification of vitamin effect")


# Remark: But for the design diagram it is better to have 'antibio' and 'vitamin'
#         as categorical variables. So before proceeding we do the recoding.
rats$antibio <- factor(rats$antibio)
rats$vitamin <- factor(rats$vitamin)

# Design Diagram
plot(DD(~antibio*vitamin,data=rats))

# Design Diagram with hypothesis tests
# If a response variable is given, then the circle="MSS" option 
# makes circles with area proportional to the mean-sum-of-squares.
# It is the MSS's that are compared in F-tests. Thus, F-tests
# compare the variation explained by the explanatory variables.
# Hence the name "analysis of variance".
plot(DD(growth~antibio*vitamin,data=rats),circle="MSS")


# Model fit, validation, and reduction
m1 <- lm(growth~antibio*vitamin,data=rats)
plot(m1)
drop1(m1,test="F")
summary(m1)

# Where is the effect?
# Tukey grouping
(my.groups <- CLD(emmeans(m1,~antibio*vitamin),Letters=letters))
ggplot(my.groups) + 
  geom_bar(aes(x=antibio:vitamin,y=emmean,fill=antibio:vitamin),stat="identity") + 
  geom_errorbar(aes(x=antibio:vitamin,ymin=lower.CL,ymax=upper.CL),width=0.25) +
  geom_text(aes(x=antibio:vitamin,y=1.05*max(my.groups$upper.CL),label=.group)) +
  ylab("Estimated marginal mean") + guides(fill=FALSE)


# Corresponding plot of family-wise confidence intervals
plot(pairs(emmeans(m1,~antibio*vitamin),reverse=TRUE),int.adjust="tukey") + 
  geom_vline(xintercept = 0)


# Family-wise confidence intervals of effect modifications
plot(pairs(emmeans(m1,~antibio|vitamin),reverse=TRUE)) + geom_vline(xintercept = 0)
plot(pairs(emmeans(m1,~vitamin|antibio),reverse=TRUE)) + geom_vline(xintercept = 0)
